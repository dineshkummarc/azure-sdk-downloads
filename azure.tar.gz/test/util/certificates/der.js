module.exports = require('../../../lib/util/certificates/der.js');
