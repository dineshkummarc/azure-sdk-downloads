module.exports = require('../../../lib/util/certificates/pkcs.js');
