This sample shows how to use the Azure ServiceRuntime API to discover endpoint address and port from the 
current role instance setting, How to retrieve local storage resource information (particularly the 
diagnostic store), and how to retrieve role configuration settings.

To use this sample, you must place a copy of node.exe (v0.6.11 or higher) in the HelloWorker directory.